﻿function InitializeControl(controlid) {
    var WaldoNAVPadHTMLEditor =
        '<textarea id="WaldoNAVPadControl">Hello, World!</textarea>'
        //'<div id="WaldoNAVPadControl">Click here to edit!</div>'
  
    $('#' + controlid).append(WaldoNAVPadHTMLEditor);

    tinymce.init({
        selector: '#WaldoNAVPadControl',
        height: 500,
        plugins: [
          'advlist autolink lists link image charmap print preview anchor',
          'searchreplace visualblocks code fullscreen',
          'insertdatetime media table contextmenu paste code'
        ],
        toolbar: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | link image',
        content_css: [
          '//fast.fonts.net/cssapi/e6dc9b99-64fe-4292-ad98-6974f93cd2a2.css',
          '//www.tinymce.com/css/codepen.min.css'
        ]
    });

}

function InvokeEvent(Method, Arguments) {
    Microsoft.Dynamics.NAV.InvokeExtensibilityMethod(Method, Arguments)
}

function SendRequest(method, arguments) {
    if (method === 'GetHTML') {
        alert('GetHTML')
    }
}

$(document).ready(function () {
    InitializeControl('ControlAddIn');

    InvokeEvent('ControlAddInReady', [])
})